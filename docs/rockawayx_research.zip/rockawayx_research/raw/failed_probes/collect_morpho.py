import json,urllib.request,datetime,pathlib
ROOT=pathlib.Path(__file__).resolve().parent
capture=json.loads((ROOT/'dashboard_capture.json').read_text())
a=capture['page1'].split('\n');a=[x.strip() for x in a if x.strip()]
rows=[a[i:i+8] for i in range(8,len(a),8)]+[[c['text'] for c in row] for row in capture['page2'][1:]]
asset='address symbol name decimals price { usd timestamp }'
market='''marketId lltv irmAddress loanAsset {ASSET} collateralAsset {ASSET} oracle {address type} state {blockNumber timestamp supplyAssets supplyAssetsUsd borrowAssets borrowAssetsUsd collateralAssets collateralAssetsUsd utilization liquidityAssets liquidityAssetsUsd price supplyApy borrowApy}'''.replace('ASSET',asset)
fields='''address name symbol listed creationTimestamp asset {ASSET} owner {address} curator {address} curators {items{name verified}} totalAssets totalAssetsUsd totalSupply idleAssets idleAssetsUsd liquidity liquidityUsd forceDeallocatableLiquidity forceDeallocatableLiquidityUsd apy netApy performanceFee managementFee adapters(first:100) {items {__typename address type assets assetsUsd forceDeallocatePenalty ... on MorphoMarketV1Adapter {positions(first:100){items{state{timestamp supplyAssets supplyAssetsUsd borrowAssets collateral} market {MARKET}}}} ... on MetaMorphoAdapter {metaMorpho {address name}} ... on MorphoVaultV2Adapter {innerVault {address name}}}}'''.replace('ASSET',asset).replace('MARKET',market)
q='{'+ '\n'.join('v%d:vaultV2ByAddress(address:"%s",chainId:%d){%s}'%(i,r[1],{'ethereum':1,'base':8453,'monad':143}[r[3]],fields) for i,r in enumerate(rows) if r[4]=='morpho')+'}'
(ROOT/'morpho_query.graphql').write_text(q)
req=urllib.request.Request('https://api.morpho.org/graphql',data=json.dumps({'query':q}).encode(),headers={'Content-Type':'application/json'})
try:
 r=json.load(urllib.request.urlopen(req,timeout=45))
except Exception as e:r={'error':str(e)}
(ROOT/'raw/morpho_vaults.json').write_text(json.dumps({'collected_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'query':q,'response':r},indent=2))
print(json.dumps(r)[:4000])
