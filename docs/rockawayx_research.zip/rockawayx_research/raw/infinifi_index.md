# infiniFi Documentation

- [infiniFi Docs Hub](https://docs.infinifi.xyz/index.md): Welcome to infiniFi - amplified DeFi returns through fractional reserve banking
- [Whitepaper](https://docs.infinifi.xyz/whitepaper/index.md): The Fractional Reserve Stablecoin: The Natural Evolution of Modern Banking
- [Oracles](https://docs.infinifi.xyz/oracles.md): Oracle infrastructure powering infiniFi's price feeds
- [Vaults](https://docs.infinifi.xyz/vaults.md): Current infiniFi vault data
- [Deposit Quickstart](https://docs.infinifi.xyz/deposit-quickstart.md): How to deposit USDC and get iUSD - Agent Quickstart Guide
- [Pendle Liquidity Transfer](https://docs.infinifi.xyz/pendle-liquidity-transfer/index.md): Walkthrough for Pendle liquidity providers migrating to infiniFi
- [Security](https://docs.infinifi.xyz/audits.md): External verification, monitoring, bug bounty, and contract governance information for infiniFi.
- [Risk Disclosures](https://docs.infinifi.xyz/risk-disclosures.md): Risk scenarios covering bank runs, underlying protocol losses, bad debt, yield changes, and market downturns.
- [Slashing mechanics](https://docs.infinifi.xyz/slashing-mechanics.md): How infiniFi applies realized losses to Locked-iUSD before losses reach senior depositors.
- [Developer Summary](https://docs.infinifi.xyz/dev-docs/summary.md): High-level overview of the infiniFi protocol architecture
- [Contract Addresses](https://docs.infinifi.xyz/dev-docs/contracts.md): Deployed contract addresses for infiniFi on all networks
- [Changelog](https://docs.infinifi.xyz/dev-docs/changelog.md): Protocol updates and changes
- [Core](https://docs.infinifi.xyz/dev-docs/core/index.md): Central authority and role-based access control
- [InfiniFiCore.sol](https://docs.infinifi.xyz/dev-docs/core/infini-fi-core.md): Central role registry for the infiniFi protocol
- [CoreControlled.sol](https://docs.infinifi.xyz/dev-docs/core/core-controlled.md): Base contract for role-based access control
- [Gateway](https://docs.infinifi.xyz/dev-docs/gateway/index.md): Entry point for user interactions
- [InfiniFiGatewayV1.sol](https://docs.infinifi.xyz/dev-docs/gateway/infini-fi-gateway-v1.md): Main gateway for user interactions
- [Tokens](https://docs.infinifi.xyz/dev-docs/tokens/index.md): Protocol token implementations
- [ReceiptToken.sol](https://docs.infinifi.xyz/dev-docs/tokens/receipt-token.md): iUSD - Protocol deposit receipt token
- [StakedToken.sol](https://docs.infinifi.xyz/dev-docs/tokens/staked-token.md): siUSD - Staked position token
- [LockedPositionToken.sol](https://docs.infinifi.xyz/dev-docs/tokens/locked-position-token.md): liUSD-xw - Locked position tokens
- [Funding](https://docs.infinifi.xyz/dev-docs/funding/index.md): Mint and redeem controllers
- [MintController.sol](https://docs.infinifi.xyz/dev-docs/funding/mint-controller.md): Controls iUSD minting operations
- [RedeemController.sol](https://docs.infinifi.xyz/dev-docs/funding/redeem-controller.md): Controls iUSD redemption operations
- [RedemptionPool.sol](https://docs.infinifi.xyz/dev-docs/funding/redemption-pool.md): Manages the redemption queue
- [Locking](https://docs.infinifi.xyz/dev-docs/locking/index.md): Lock and unlock iUSD positions
- [LockingController.sol](https://docs.infinifi.xyz/dev-docs/locking/locking-controller.md): Manages iUSD lock operations
- [UnwindingModule.sol](https://docs.infinifi.xyz/dev-docs/locking/unwinding-module.md): Handles the unbonding process
- [Finance](https://docs.infinifi.xyz/dev-docs/finance/index.md): Yield distribution and accounting
- [Accounting.sol](https://docs.infinifi.xyz/dev-docs/finance/accounting.md): Protocol accounting and NAV calculations
- [YieldSharing.sol](https://docs.infinifi.xyz/dev-docs/finance/yield-sharing.md): Yield distribution to stakers and lockers
- [Governance](https://docs.infinifi.xyz/dev-docs/governance/index.md): Protocol governance and timelocks
- [AllocationVoting.sol](https://docs.infinifi.xyz/dev-docs/governance/allocation-voting.md): Farm allocation voting system
- [Timelock.sol](https://docs.infinifi.xyz/dev-docs/governance/timelock.md): Delayed execution for governance actions
- [MinorRolesManager.sol](https://docs.infinifi.xyz/dev-docs/governance/minor-roles-manager.md): Management of non-critical roles
- [Integrations](https://docs.infinifi.xyz/dev-docs/integrations/index.md): Farm integrations and registry
- [Farm.sol](https://docs.infinifi.xyz/dev-docs/integrations/farm.md): Base contract for farm integrations
- [FarmRegistry.sol](https://docs.infinifi.xyz/dev-docs/integrations/farm-registry.md): Central registry of all farms
- [Farms](https://docs.infinifi.xyz/dev-docs/integrations/farms.md): Specific farm implementations
- [API Documentation](https://docs.infinifi.xyz/dev-docs/api-documentation.md): External API endpoints and data access
- [Roles Documentation](https://docs.infinifi.xyz/dev-docs/roles-documentation.md): Protocol roles and permissions
- [Research Overview](https://docs.infinifi.xyz/research.md): Deep dives into DeFi mechanisms and infiniFi's approach
- [Liquid keeper reserve](https://docs.infinifi.xyz/liquid-keeper-reserve.md): How infiniFi keeps its liquid USDC reserve near the configured target
- [Risk Assessment Framework](https://docs.infinifi.xyz/risk-assessment-framework.md): How infiniFi evaluates and manages protocol risk

## Optional

- [GitHub](https://github.com/InfiniFi-Labs)
- [Discord](https://discord.gg/infinifi)


This documentation is built and hosted on [Mintlify](https://mintlify.com), a developer documentation platform.