> ## Documentation Index
> Fetch the complete documentation index at: https://docs.infinifi.xyz/llms.txt
> Use this file to discover all available pages before exploring further.

# Vaults

> Current infiniFi vault data

export const PdfCard = ({title, href}) => {
  const [open, setOpen] = useState(false);
  const dialogRef = useRef(null);
  const previewHref = `https://mozilla.github.io/pdf.js/web/viewer.html?file=${encodeURIComponent(href)}`;
  useEffect(() => {
    if (!open || !dialogRef.current) {
      return;
    }
    if (!dialogRef.current.open) {
      dialogRef.current.showModal();
    }
  }, [open]);
  useEffect(() => {
    const close = () => setOpen(false);
    window.addEventListener("pdf-card:close", close);
    return () => window.removeEventListener("pdf-card:close", close);
  }, []);
  return <>
            <button className="pdf-card" type="button" onClick={() => {
    window.dispatchEvent(new Event("pdf-card:close"));
    setOpen(true);
  }}>
                <span className="pdf-card-icon" aria-hidden="true">
                    PDF
                </span>
                <span className="pdf-card-title">{title}</span>
            </button>
            {open && <dialog ref={dialogRef} className="pdf-modal" aria-label={title} onCancel={() => setOpen(false)} onClick={event => {
    if (event.target === event.currentTarget) {
      setOpen(false);
    }
  }}>
                    <div className="pdf-modal-card">
                        <div className="pdf-modal-header">
                            <strong>{title}</strong>
                            <button type="button" onClick={() => setOpen(false)}>
                                Close
                            </button>
                        </div>
                        <iframe className="pdf-modal-frame" src={previewHref} title={title} />
                    </div>
                </dialog>}
        </>;
};

This page is generated from the infiniFi protocol API once per day.

<h2 className="vault-section-heading">Active Vaults</h2>

<h3 className="vault-type-heading">Liquid</h3>

#### Liquid Cap stcUSD

<Badge stroke shape="pill" color="purple">
  Bucket 0w
</Badge>

<Badge stroke shape="pill" color="green">
  Liquid
</Badge>

<Badge stroke shape="pill" color="surface">
  stcUSD
</Badge>

> Cap is a covered credit protocol issuing cUSD and its yield-bearing counterpart stcUSD. The vault routes capital through Cap's Credit Engine, where institutional operators borrow against overcollateralized delegations to execute yield strategies, with Aave supply rates serving as the floor benchmark. Yield accrues continuously with redemption available directly.

* Farm address: [`0xAc21B22B5aEb11bc32De4ecF59E4538fCa48b694`](https://etherscan.io/address/0xAc21B22B5aEb11bc32De4ecF59E4538fCa48b694)
* Underlying address (stcUSD): [`0x88887bE419578051FF9F4eb6C858A951921D8888`](https://etherscan.io/address/0x88887bE419578051FF9F4eb6C858A951921D8888)

#### Multi Farm

<Badge stroke shape="pill" color="purple">
  Bucket 0w
</Badge>

<Badge stroke shape="pill" color="green">
  Liquid
</Badge>

> The Multi Farm is a swap farm allowing users to swap between various tokens.

* Farm address: [`0x90787c1b99F47EFfEE0db0aB9D4e33CdC3e6bFa7`](https://etherscan.io/address/0x90787c1b99F47EFfEE0db0aB9D4e33CdC3e6bFa7)

#### Spark sUSDC

<Badge stroke shape="pill" color="purple">
  Bucket 0w
</Badge>

<Badge stroke shape="pill" color="green">
  Liquid
</Badge>

<Badge stroke shape="pill" color="surface">
  sUSDC
</Badge>

> Spark is the liquidity and yield infrastructure layer within the Sky (formerly MakerDAO) ecosystem. The sUSDC vault deposits USDC into the Sky Savings Rate, with yield funded by Sky's revenue from collateralized loans, RWAs, and liquidity activities. Yield accrues continuously with instant redemption and no lockup period.

* Farm address: [`0xd880D7C5CaFdbE2AEc281250995abF612235e563`](https://etherscan.io/address/0xd880D7C5CaFdbE2AEc281250995abF612235e563)
* Underlying address (sUSDC): [`0xBc65ad17c5C0a2A4D159fa5a503f4992c7B545FE`](https://etherscan.io/address/0xBc65ad17c5C0a2A4D159fa5a503f4992c7B545FE)

<h3 className="vault-type-heading">Illiquid</h3>

#### 3F Bridge Facilitator

<Badge stroke shape="pill" color="purple">
  Bucket 0w
</Badge>

<Badge stroke shape="pill" color="orange">
  Illiquid
</Badge>

<Badge stroke shape="pill" color="surface">
  USDC
</Badge>

>

* Farm address: [`0xfD1Ea12d29B90630b265DBbc6Af88266d1a83dE4`](https://etherscan.io/address/0xfD1Ea12d29B90630b265DBbc6Af88266d1a83dE4)
* Underlying address (USDC): [`0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48`](https://etherscan.io/address/0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48)

#### BASE Liquidity Farm

<Badge stroke shape="pill" color="purple">
  Bucket 1w
</Badge>

<Badge stroke shape="pill" color="orange">
  Illiquid
</Badge>

<Badge stroke shape="pill" color="surface">
  USDC
</Badge>

>

* Farm address: [`0x4cE95DaF47410f21008fDa15D27c801f462Fb872`](https://etherscan.io/address/0x4cE95DaF47410f21008fDa15D27c801f462Fb872)
* Underlying address (USDC): [`0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48`](https://etherscan.io/address/0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48)

#### f(x) fxSAVE

<Badge stroke shape="pill" color="purple">
  Bucket 1w
</Badge>

<Badge stroke shape="pill" color="orange">
  Illiquid
</Badge>

<Badge stroke shape="pill" color="surface">
  fxSAVE
</Badge>

> f(x) Protocol is a DeFi platform on Ethereum built by AladdinDAO. The vault deposits into fxSAVE, an auto-compounding yield position that sources returns from the FX stability pool and fees generated by traders on the FX perpetual trading product. Yield auto-compounds continuously with redemptions available within 1 week, contingent on liquidity.

* Farm address: [`0x78A31bD6cAca12BdF83F8A608076006C1F58F363`](https://etherscan.io/address/0x78A31bD6cAca12BdF83F8A608076006C1F58F363)
* Underlying address (fxSAVE): [`0x7743e50F534a7f9F1791DdE7dCD89F7783Eefc39`](https://etherscan.io/address/0x7743e50F534a7f9F1791DdE7dCD89F7783Eefc39)

#### FalconX Institutional

<Badge stroke shape="pill" color="purple">
  Bucket 1w
</Badge>

<Badge stroke shape="pill" color="orange">
  Illiquid
</Badge>

<Badge stroke shape="pill" color="surface">
  USDC
</Badge>

> FalconX is a leading institutional crypto prime brokerage. The vault deploys capital into FalconX's institutional lending program, which provides financing to KYC'd counterparties including hedge funds, market makers, and trading firms. Yield accrues continuously with redemption terms of 1 week.

* Farm address: [`0xe919C66475f2F30d285c768853E6B5b23ef181Cf`](https://etherscan.io/address/0xe919C66475f2F30d285c768853E6B5b23ef181Cf)
* Underlying address (USDC): [`0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48`](https://etherscan.io/address/0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48)

#### Morpho infiniFi Ecosystem Vault

<Badge stroke shape="pill" color="purple">
  Bucket 1w
</Badge>

<Badge stroke shape="pill" color="orange">
  Illiquid
</Badge>

<Badge stroke shape="pill" color="surface">
  steakUSDCinfinifi
</Badge>

> A Steakhouse Financial Morpho vault curated for the infiniFi ecosystem. The vault allocates USDC across Morpho lending markets, with Steakhouse actively managing risk parameters and market selection. Yield accrues continuously with liquidity available within 1 week.

* Farm address: [`0x76D2E84009dAE457f8667D823c7c96e9A7c35B78`](https://etherscan.io/address/0x76D2E84009dAE457f8667D823c7c96e9A7c35B78)
* Underlying address (steakUSDCinfinifi): [`0xBEeF1f5Bd88285E5B239B6AAcb991d38ccA23Ac9`](https://etherscan.io/address/0xBEeF1f5Bd88285E5B239B6AAcb991d38ccA23Ac9)

#### New Silver 2 Senior

<Badge stroke shape="pill" color="purple">
  Bucket 1w
</Badge>

<Badge stroke shape="pill" color="orange">
  Illiquid
</Badge>

<Badge stroke shape="pill" color="surface">
  USDC
</Badge>

> New Silver is a technology-first private lender focused on short duration residential investment property loans in the US. It has originated \$501M+ in loans since inception in 2018. Currently, New Silver has a \$50M allocation from Sky, and was one of the original RWA vaults that received an allocation from Maker. Senior tranche. Yield accrues constantly with 1 week redemption.

<div className="vault-docs">
  <CardGroup cols={3}>
    <PdfCard
      title={"New Silver fund press release - Qiro"}
      href={
            "https://raw.githubusercontent.com/InfiniFi-Labs/documents/master/new-silver/NS_Fund_PR_Qiro.pdf"
        }
    />

    <PdfCard
      title={"New Silver investor summary"}
      href={
            "https://raw.githubusercontent.com/InfiniFi-Labs/documents/master/new-silver/Investor%20Summary-1.pdf"
        }
    />
  </CardGroup>
</div>

* Farm address: [`0x79e1B8e45932A7C802eA3dAb3844e5DEa68d971f`](https://etherscan.io/address/0x79e1B8e45932A7C802eA3dAb3844e5DEa68d971f)
* Underlying address (USDC): [`0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48`](https://etherscan.io/address/0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48)

#### Fasanara Genesis Fund

<Badge stroke shape="pill" color="purple">
  Bucket 4w
</Badge>

<Badge stroke shape="pill" color="orange">
  Illiquid
</Badge>

<Badge stroke shape="pill" color="surface">
  USDC
</Badge>

> Fasanara Digital is the crypto arm of Fasanara Capital (\$5.5B AUM). Genesis Alpha is driven by a digital asset arbitrage strategy designed to deliver consistent, uncorrelated excess returns. The Fund's long-term investment objective and strategy focuses on identifying and capturing market inefficiencies and building a diversified portfolio of derivative and spot assets. NAV updated monthly with monthly redemptions.

<div className="vault-docs">
  <CardGroup cols={3}>
    <PdfCard
      title={"Genesis NAV (26 Feb 2026)"}
      href={
            "https://raw.githubusercontent.com/InfiniFi-Labs/documents/master/fasanara/genesis-nav/2026-02-26-genesis-nav.pdf"
        }
    />

    <PdfCard
      title={"Fasanara corporate overview (Q4 2025)"}
      href={
            "https://raw.githubusercontent.com/InfiniFi-Labs/documents/master/fasanara/Corporate%20Overview%20-%20Fasanara%20Presentation%20(Q4%202025).pdf"
        }
    />
  </CardGroup>
</div>

* Farm address: [`0x9E5efC5F387D8661C1AFB2469B7EeF6972451852`](https://etherscan.io/address/0x9E5efC5F387D8661C1AFB2469B7EeF6972451852)
* Underlying address (USDC): [`0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48`](https://etherscan.io/address/0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48)

#### Fasanara mGLOBAL (GDADF)

<Badge stroke shape="pill" color="purple">
  Bucket 4w
</Badge>

<Badge stroke shape="pill" color="orange">
  Illiquid
</Badge>

<Badge stroke shape="pill" color="surface">
  USDC
</Badge>

> Fasanara Digital is the crypto arm of Fasanara Capital (\$5.5B AUM). The mGlobal vault is a tokenized representation of their Global Diversified Asset Debt Fund (GDADF) which is an asset backed lending vehicle with an 8 year track record that deploys capital into over 700,000 short dated receivables with an average tenor of 100 days. Yield is distributed weekly with monthly redemptions.

<div className="vault-docs">
  <CardGroup cols={3}>
    <PdfCard title={"GDADF NAV (27 Apr 2026)"} href={"https://raw.githubusercontent.com/InfiniFi-Labs/documents/master/fasanara/gdadf-nav/2026-04-27-gdadf-nav.pdf"} />

    <PdfCard title={"GDADF NAV (13 Apr 2026)"} href={"https://raw.githubusercontent.com/InfiniFi-Labs/documents/master/fasanara/gdadf-nav/2026-04-13-gdadf-nav.pdf"} />

    <PdfCard title={"GDADF NAV (06 Apr 2026)"} href={"https://raw.githubusercontent.com/InfiniFi-Labs/documents/master/fasanara/gdadf-nav/2026-04-06-gdadf-nav.pdf"} />
  </CardGroup>

  <Accordion title={"View 8 more documents"} icon="file-pdf">
    <CardGroup cols={3}>
      <PdfCard title={"GDADF NAV (30 Mar 2026)"} href={"https://raw.githubusercontent.com/InfiniFi-Labs/documents/master/fasanara/gdadf-nav/2026-03-30-gdadf-nav.pdf"} />

      <PdfCard title={"GDADF NAV (16 Mar 2026)"} href={"https://raw.githubusercontent.com/InfiniFi-Labs/documents/master/fasanara/gdadf-nav/2026-03-16-gdadf-nav.pdf"} />

      <PdfCard title={"GDADF NAV (09 Mar 2026)"} href={"https://raw.githubusercontent.com/InfiniFi-Labs/documents/master/fasanara/gdadf-nav/2026-03-09-gdadf-nav.pdf"} />

      <PdfCard title={"GDADF NAV (02 Mar 2026)"} href={"https://raw.githubusercontent.com/InfiniFi-Labs/documents/master/fasanara/gdadf-nav/2026-03-02-gdadf-nav.pdf"} />

      <PdfCard title={"GDADF NAV (23 Feb 2026)"} href={"https://raw.githubusercontent.com/InfiniFi-Labs/documents/master/fasanara/gdadf-nav/2026-02-23-gdadf-nav.pdf"} />

      <PdfCard title={"Fasanara asset-based finance overview (Q4 2025)"} href={"https://raw.githubusercontent.com/InfiniFi-Labs/documents/master/fasanara/Asset-Based%20Finance%20-%20Fasanara%20Overview%20(Q4%202025).pdf"} />

      <PdfCard title={"Fasanara corporate overview (Q4 2025)"} href={"https://raw.githubusercontent.com/InfiniFi-Labs/documents/master/fasanara/Corporate%20Overview%20-%20Fasanara%20Presentation%20(Q4%202025).pdf"} />

      <PdfCard title={"GDADF factsheet (November 2025)"} href={"https://raw.githubusercontent.com/InfiniFi-Labs/documents/master/fasanara/GDADF%20Factsheet%20(November%202025).pdf"} />
    </CardGroup>
  </Accordion>
</div>

* Farm address: [`0x2fa5E6C5549BEdF98A935Cac3BB4337459c74897`](https://etherscan.io/address/0x2fa5E6C5549BEdF98A935Cac3BB4337459c74897)
* Underlying address (USDC): [`0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48`](https://etherscan.io/address/0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48)

#### New Silver

<Badge stroke shape="pill" color="purple">
  Bucket 8w
</Badge>

<Badge stroke shape="pill" color="orange">
  Illiquid
</Badge>

<Badge stroke shape="pill" color="surface">
  USDC
</Badge>

> New Silver is a technology-first private lender focused on short duration residential investment property loans in the US. It has originated \$501M+ in loans since inception in 2018. Currently, New Silver has a \$50M allocation from Sky, and was one of the original RWA vaults that received an allocation from Maker. Yield accrues constantly with 8 week redemption.

<div className="vault-docs">
  <CardGroup cols={3}>
    <PdfCard
      title={"New Silver fund press release - Qiro"}
      href={
            "https://raw.githubusercontent.com/InfiniFi-Labs/documents/master/new-silver/NS_Fund_PR_Qiro.pdf"
        }
    />

    <PdfCard
      title={"New Silver investor summary"}
      href={
            "https://raw.githubusercontent.com/InfiniFi-Labs/documents/master/new-silver/Investor%20Summary-1.pdf"
        }
    />
  </CardGroup>
</div>

* Farm address: [`0x277FdF6Dc5c53C5c2828188Da84B9593A50884C1`](https://etherscan.io/address/0x277FdF6Dc5c53C5c2828188Da84B9593A50884C1)
* Underlying address (USDC): [`0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48`](https://etherscan.io/address/0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48)

<h2 className="vault-section-heading">Paused Vaults</h2>

<h3 className="vault-type-heading">Liquid</h3>

#### Aave USDC

<Badge stroke shape="pill" color="purple">
  Bucket 0w
</Badge>

<Badge stroke shape="pill" color="green">
  Liquid
</Badge>

<Badge stroke shape="pill" color="surface">
  USDC
</Badge>

> Aave is the largest decentralized lending protocol with \$66B+ in assets. The vault supplies USDC to Aave V3 on Ethereum, earning algorithmically determined yield from borrower demand across the protocol's pools. Yield accrues continuously with instant redemption subject to pool utilization.

* Farm address: [`0xbFd5FC8DecA3C6128bfCE0FE46c25616811c3580`](https://etherscan.io/address/0xbFd5FC8DecA3C6128bfCE0FE46c25616811c3580)
* Underlying address (USDC): [`0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48`](https://etherscan.io/address/0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48)

#### Euler Sentora USDC

<Badge stroke shape="pill" color="purple">
  Bucket 0w
</Badge>

<Badge stroke shape="pill" color="green">
  Liquid
</Badge>

<Badge stroke shape="pill" color="surface">
  USDC
</Badge>

> A conservative USDC vault on Euler, curated by Sentora as part of their PYUSD cluster. The vault lends USDC to borrowers supplying vaults from the Sentora PYUSD ecosystem as collateral, with Sentora managing risk parameters. Yield accrues continuously with instant redemption subject to available liquidity.

* Farm address: [`0x6FBc446f25Ab5141C4F7E7711E52DFc0AdA407A5`](https://etherscan.io/address/0x6FBc446f25Ab5141C4F7E7711E52DFc0AdA407A5)
* Underlying address (USDC): [`0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48`](https://etherscan.io/address/0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48)

#### Horizon USDC

<Badge stroke shape="pill" color="purple">
  Bucket 0w
</Badge>

<Badge stroke shape="pill" color="green">
  Liquid
</Badge>

<Badge stroke shape="pill" color="surface">
  USDC
</Badge>

> Aave Horizon is a dedicated institutional lending market where qualified institutions borrow stablecoins against tokenized RWA collateral including US Treasuries from Superstate, Circle, and VanEck. The vault supplies USDC to earn yield from institutional borrowers. Yield accrues continuously with instant redemption available to permissionless lenders.

* Farm address: [`0x817d93DbdFd8190bbef0a73fCf5Dd9DA5A87E032`](https://etherscan.io/address/0x817d93DbdFd8190bbef0a73fCf5Dd9DA5A87E032)
* Underlying address (USDC): [`0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48`](https://etherscan.io/address/0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48)


This documentation is built and hosted on [Mintlify](https://mintlify.com), a developer documentation platform.