> ## Documentation Index
> Fetch the complete documentation index at: https://docs.infinifi.xyz/llms.txt
> Use this file to discover all available pages before exploring further.

# Farms

> Specific farm implementations

## Farm Implementations

infiniFi integrates with multiple DeFi protocols as yield sources.

## Liquid Farms

* **AAVE** — Lending protocol
* **Spark** — sUSDC yield

## Illiquid Farms (Pendle)

Pendle Principal Token (PT) farms with various maturities:

* PT-USDS
* PT-USR
* PT-wstUSR
* PT-slvlUSD

<Note>
  Farms are added and deprecated over time. See the [Changelog](../changelog)
  for current status.
</Note>

## Movement Contracts

Specific contracts for farm capital movement:

* `BeforeRedeemHook.sol`
* `AfterMintHook.sol`
* `EmergencyWithdrawal.sol`
* `ManualRebalancer.sol`


This documentation is built and hosted on [Mintlify](https://mintlify.com), a developer documentation platform.