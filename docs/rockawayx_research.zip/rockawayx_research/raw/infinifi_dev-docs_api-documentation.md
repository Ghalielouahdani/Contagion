> ## Documentation Index
> Fetch the complete documentation index at: https://docs.infinifi.xyz/llms.txt
> Use this file to discover all available pages before exploring further.

# API Documentation

> External API endpoints and data access

Documentation for infiniFi's external APIs and data endpoints.

## Overview

infiniFi provides APIs for:

* Protocol state queries
* Historical data access
* Integration endpoints

## Resources

<Card title="GitHub" icon="github" href="https://github.com/InfiniFi-Labs">
  View the complete API documentation in the backend repository.
</Card>

<Note>
  Full API documentation is maintained in the infinifi-backend repository.
</Note>


This documentation is built and hosted on [Mintlify](https://mintlify.com), a developer documentation platform.