import json,pathlib,csv
P=pathlib.Path(__file__).parent
url='https://app.upshift.finance/pools/1/0xcd69123b3FBBfC666E1f6a501da27B564C00De54'
address='0xcd69123b3FBBfC666E1f6a501da27B564C00De54'
f=P/'risk_data.json';d=json.loads(f.read_text());r=next(v for v in d['vaults'] if v['vault_address']==address)
r['portfolio']['linked_ui']={'source_url':url,'evidence_file':'raw/upshift_tori.txt','ui_last_updated':'2026-10-10T12:05:07 (displayed; timezone unspecified)','net_value_usd':17167108,'tvl_usd_display_rounded':17160000,'total_apy_7d_pct':3.87,'receipt_token':'etrUSD','deposit_tokens':['trUSD','USDC','USDT'],'protocol_net_allocations_usd':{'Curve':6125354,'Fluid':2634459,'Morpho':750248,'Pendle V2':4111770,'Tori':3540550,'Idle ETH':4727},'morpho_borrower_position':{'supplied_strUSD_value_usd':3091986,'borrowed_USDC_value_usd':2341738,'net_value_usd':750248,'note':'Borrower exposure within this strategy, distinct from USDC lending vault named RockawayX Tori Ecosystem.'},'subaccounts':['0xa8a697F7fEc0E99C1e6D82ADD6C80AaFB07Da60e','0xE7a7cAb7C37f9f687f1929D742c54d4Acb8f1271','0x31EE3D74939BE254a333C99c4Cd1EAc143D8D631'],'fees_pct':{'USDC_USDT_mint':0.10,'platform':0.20,'performance':10,'withdrawal':0}}
r['exit_information']={'source_url':url,'withdrawal_period_days':7,'withdrawal_queue_usd_display_rounded':6220000,'liquidity_usd_display_rounded':13870,'reserve_pct_display':4,'dex_routes':'Curve and Pendle positions visible; exact pools and size-specific quotes not collected','note':'Queue liquidity is distinct from portfolio TVL and idle ETH. Seven-day period is a stated process, not a guarantee of full liquidity.'}
r['risk_parameters']={'lltv':None,'oracle_address':None,'leverage':'Observed Morpho debt/collateral USD ratio approximately 75.7358%; this is position LTV, not full-vault leverage or liquidation threshold. Pool IDs and underlying quantities unresolved.'}
f.write_text(json.dumps(d,indent=2))
f=P/'dependencies.json';d=json.loads(f.read_text())
for protocol in ['Curve','Fluid','Morpho','Pendle V2','Tori']:
 d['edges'].append({'source':address,'target':protocol,'relationship_type':'strategy_allocation','evidence_url':url,'evidence_status':'verified linked UI','ui_updated_at':'2026-10-10T12:05:07 (timezone unspecified)'})
d['edges'].append({'source':address,'target':'USDC','relationship_type':'strategy_borrows','evidence_url':url,'evidence_status':'verified linked UI','borrowed_value_usd':2341738,'collateral':'strUSD','scope':'Morpho sub-position'})
f.write_text(json.dumps(d,indent=2))
f=P/'vaults.csv';rows=list(csv.DictReader(f.open()))
v=next(v for v in rows if v['vault_contract_address']==address);v.update(tvl_usd_live='17167108',apy_live='0.0387',live_source_url=url,curator_manager='RockawayX (linked UI strategist)',status='live UI; withdrawal queue visible',notes=v['notes']+' Linked UI strategy exposure updated 2026-10-10 12:05:07; debt and seven-day withdrawal queue observed.')
with f.open('w',newline='') as h:w=csv.DictWriter(h,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
