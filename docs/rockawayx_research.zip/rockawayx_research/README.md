# RockawayX research package

Read recommendations.md first, then data_sources.md for reproduction and limitations.

The requested five data/report files and screenshots are included, with raw API/DOM evidence and public SQL. All 33 dashboard entries are inventoried; 14 Morpho V2 vaults have adapter/market snapshots, and four major non-Morpho linked products were inspected. This is not a claim to have fully decoded all33 strategies.

CSV live APY is a decimal annual rate, while dashboard APY is the displayed percentage string. Empty numeric cells mean unavailable, not zero. Cached dashboard TVL is rounded. API quantities labelled raw are token base units; convert with recorded decimals, preferably Decimal. Asset/market identities must include chain. Historical issuer backing edges are not current exposure measurements. Vault lender collateral is held by borrowers, not by the vault.

Reproduction: `python fetch_live.py` refreshes Morpho GraphQL snapshots using the captured configs. The build/enrichment scripts document report construction but do not constitute a general discovery crawler; rerunning build_package.py will overwrite the later Y10K annotation unless re-added. Dune access needs an API key and the main query currently needs SQL repair. Failed initial GraphQL probes are archived in raw/failed_probes; they are not the working collector.

Screenshots include dashboard overview/table, Dune failure, Kamino allocations, Lista allocations and Upshift Tori exposure/queue. UI figures were collected in the documented session; exact capture times are not available for every screenshot. Raw numeric responses carry per-request timestamps and indexed blocks.
