import json,csv,re,pathlib,datetime
P=pathlib.Path(__file__).parent
load=lambda f:json.loads((P/f).read_text())
dump=lambda f,d:(P/f).write_text(json.dumps(d,indent=2))
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
dash=load('dashboard_capture.json');lines=[x.strip() for x in dash['page1'].splitlines() if x.strip()]
rows=[lines[i:i+8] for i in range(8,len(lines),8)]+[[c['text'] for c in r] for r in dash['page2'][1:]]
links={l['text']:l['href'] for l in dash['links'] if l['href'].startswith('https://')}
for r in dash['page2'][1:]:
 if r[0]['links']:links[r[0]['text']]=r[0]['links'][0]
configs={x['address'].lower():x for x in load('raw/morpho_rest_configs.json')}
states={x['address'].lower():x for x in load('raw/morpho_rest_states.json')}
live={x['address'].lower():x for x in load('raw/morpho_live.json')}
queries={'morpho':6932588,'midas':6912479,'kamino':6912427,'feather':6973183,'ember':7325700,'lista':7356289,'upshift':7444730,'accountable':7698787,'oku':8603650}
def num(s):
 s=s.replace('$','').lower();m=re.match(r'([\d.]+)([mk]?)',s);return float(m[1])*{'':1,'m':1e6,'k':1e3}[m[2]] if m else None
vaults=[];deps=[];risks=[]
def edge(a,b,t,url,status='verified',**kw):deps.append(dict(source=a,target=b,relationship_type=t,evidence_url=url,evidence_status=status,**kw))
for name,address,token,chain,protocol,category,tvl,apy in rows:
 key=address.lower();url=links.get(name);ql=f'https://dune.com/queries/{queries[protocol]}'
 reserve=bool(url and '/borrow/reserve/' in url)
 v=dict(vault_name=name,network=chain,protocol=protocol,vault_contract_address=address,underlying_asset=token,tvl_usd_dashboard_approx=num(tvl),tvl_dashboard_display=tvl,apy_dashboard_display=apy,curator_manager='Unverified; dashboard attributed to RockawayX',status='listed; operational status unverified',entity_type='lending_reserve' if reserve else 'vault_or_product',dune_query_url=ql,dashboard_query_url='https://dune.com/queries/6932634',product_url=url,collected_at=dash['collected_at'],tvl_usd_live=None,apy_live=None,live_source_url=None,notes='Dashboard cached rounded data; not unique capital.')
 edge(address,protocol,'listed_protocol',ql)
 edge(address,token,'listed_underlying_asset',ql,asset_identity='symbol only unless independently resolved')
 risk=dict(vault_address=address,vault_name=name,network=chain,collection_timestamp=now,portfolio={'dashboard_tvl':{'value':num(tvl),'unit':'USD','precision':'rounded','source_url':'https://dune.com/queries/6932634','collected_at':dash['collected_at']}},risk_parameters=None,exit_information=None,unavailable=['Borrower-level positions not collected','Executable DEX quotes and slippage curves not collected','Current issuer backing weights not established'],ethena_exposure='unverified; symbol similarity is not evidence')
 if key in live:
  g=live[key];data=g['response']['data']['vaultV2ByAddress'];c=configs[key]['response']['data'];s=states[key]['response']['data'];decimal=c['asset']['decimals']
  v.update(tvl_usd_live=data['totalAssetsUsd'],apy_live=data['netApy'],live_source_url='https://api.morpho.org/graphql',curator_manager=c['curator'],status='indexed; positive assets',notes=v['notes']+' Live APY is decimal annual rate. V2 vault; gates may restrict exits.')
  if num(tvl)==0:v['notes']+=' Dashboard shows zero despite positive live indexed assets.'
  risk['portfolio'].update(live_tvl_usd={'value':data['totalAssetsUsd'],'source_url':'https://api.morpho.org/graphql','query':g['query'],'collected_at':g['collected_at']},underlying_asset=c['asset'],total_assets_raw=s['total_assets'],total_assets_token=float(s['total_assets'])/10**decimal,idle_assets_raw=s['idle_assets'],allocated_assets_raw=s['allocated_assets'],net_apy=data['netApy'],market_allocations=[])
  risk['risk_parameters']={'vault_config':c,'source_url':configs[key]['url'],'collected_at':configs[key]['collected_at'],'vault_state':s,'state_source_url':states[key]['url'],'markets':[],'leverage':'Adapter lender positions below have collateral=0 and borrowed assets=0 where observed; no borrower leverage inferred from vault TVL.'}
  risk['exit_information']={'withdrawable_assets_raw':s['withdrawable_assets'],'withdrawable_assets_token':float(s['withdrawable_assets'])/10**decimal,'api_liquidity_usd':data['liquidityUsd'],'source_url':states[key]['url'],'collected_at':states[key]['collected_at'],'liquidity_adapter':c['liquidity_adapter'],'liquidity_data':c['liquidity_data'],'gates':c['gates'],'restrictions':'Do not equate summed market liquidity or UI aggregate liquidity with an executable withdrawal. Read gates and adapter caps, simulate current route. V2 maxWithdraw/maxRedeem return zero by design; not proof all assets are locked. No V1 withdrawal queue assumed.','execution_routes':['Configured liquidity adapter withdrawal; eth_call simulation required','Alternative adapter deallocation/reallocation subject to permissions and force-deallocation penalties; not quoted'],'dex_liquidity':None}
  edge(address,c['asset']['address'],'denominated_in','https://api.morpho.org/graphql',token_symbol=c['asset']['symbol'],chain_id=c['chain_id'])
  for a in g['adapter_positions']:
   edge(address,a['adapter'],'allocates_via_adapter','https://api.morpho.org/graphql',query=g['query'],chain_id=c['chain_id'])
   for pos in a['response']['data']['userByAddress']['marketPositions']:
    m=pos['market'];p=pos['state'];mid=m['marketId'];active=int(p['supplyAssets'])>0
    allocation=dict(adapter=a['adapter'],market_id=mid,collateral_symbol=m['collateralAsset']['symbol'] if m['collateralAsset'] else None,position=p,allocation_pct_of_tvl=100*p['supplyAssetsUsd']/data['totalAssetsUsd'] if data['totalAssetsUsd'] else None,active=active,source_url='https://api.morpho.org/graphql',query=a['query'],collected_at=g['collected_at'])
    risk['portfolio']['market_allocations'].append(allocation);risk['risk_parameters']['markets'].append(dict(**m,lltv_decimal=float(m['lltv'])/1e18,source_url='https://api.morpho.org/graphql',query=a['query'],collection_timestamp=g['collected_at'],amount_scope='Aggregate market collateral/debt; not collateral held by the vault. Token quantities are raw base units. Oracle state.price is protocol-scaled, not an ordinary USD token price.'))
    edge(a['adapter'],mid,'lends_to_market','https://api.morpho.org/graphql',active=active,supply_assets_raw=p['supplyAssets'],supply_assets_usd=p['supplyAssetsUsd'],query=a['query'],chain_id=c['chain_id'])
    edge(mid,m['loanAsset']['address'],'loan_asset','https://api.morpho.org/graphql',symbol=m['loanAsset']['symbol'],query=a['query'])
    if m['collateralAsset']:edge(mid,m['collateralAsset']['address'],'borrower_collateral','https://api.morpho.org/graphql',symbol=m['collateralAsset']['symbol'],active_vault_allocation=active,query=a['query'])
    if m['oracle']:edge(mid,m['oracle']['address'],'uses_oracle','https://api.morpho.org/graphql',oracle_type=m['oracle']['type'],query=a['query'])
  risk['ethena_exposure']='No positive direct USDe/sUSDe collateral allocation identified in this collected snapshot; indirect issuer backing remains conditional.'
 if address.startswith('0x') and len(address)!=42:v['notes']+=' Address fails 20-byte EVM length validation; preserved exactly as displayed; do not use without issuer confirmation.'
 vaults.append(v);risks.append(risk)
kam=next(r for r in risks if r['vault_name']=='RockawayX RWA USDC');ku=links['RockawayX RWA USDC']
kam['portfolio']['linked_ui']={'source_url':ku,'evidence_file':'raw/kamino_rwa.txt','collected_at':now,'tvl_usd_rounded':60640000,'borrowed_usd_rounded':56110000,'utilization_pct':92.52,'supply_apy_pct':6.04,'allocations_rounded':[{'market':a,'allocation_pct':b,'supply_usd':c,'utilization_pct':d} for a,b,c,d in [('Huma',47.05,28530000,93.27),('OnRe',36.88,22370000,91.71),('Obligate',8.38,5080000,89.46),('AUTO',5.71,3460000,99.21),('OnRe fixed 1M 8%',1.65,999880,100.06),('Prime',0,60.71,95.79)]]}
kam['exit_information']={'available_withdrawal_liquidity':None,'queue':None,'dex_liquidity':None,'note':'Supply minus borrow is not verified executable withdrawal liquidity. OnRe USDC reserve UI showed available 0 despite positive accounting gap; preserve conflict. Fixed-term allocations require maturity/route review.','source_url':ku}
for a in kam['portfolio']['linked_ui']['allocations_rounded']:edge(kam['vault_address'],a['market'],'lends_to_kamino_market',ku,allocation_pct=a['allocation_pct'])
lu=links['RockawayX YIELD PT'];lr=next(r for r in risks if r['vault_name']=='RockawayX YIELD PT')
lr['portfolio']['linked_ui']={'source_url':lu,'evidence_file':'raw_lista.txt','collected_at':now,'tvl_usd':1156171.77,'apy_pct':4.88,'utilization_pct':85.46,'allocations':[{'collateral':'PT-sUSDai-15OCT2026 (Arbitrum-labelled)','allocation_pct':99.98,'supply_usdt_rounded':1160000},{'collateral':'PT-reUSD-25JUN2026 (Ethereum-labelled)','allocation_pct':0.01,'supply_usdt':181.17},{'collateral':'PT-sUSDE-7MAY2026 (Ethereum)','allocation_pct':0},{'collateral':'PT-sUSDE-18JUN2026 (Plasma)','allocation_pct':0},{'collateral':'PT-sUSDE-9APR2026 (Plasma)','allocation_pct':0}]}
lr['exit_information']={'available_withdrawal_liquidity_usd_ui':168007.84,'source_url':lu,'redemption_restrictions':None,'queue':None,'dex_liquidity':None,'note':'UI quote only; contract simulation needed. Cross-chain collateral wrapper addresses and oracle unresolved.'}
lr['ethena_exposure']='sUSDe collateral rows exist but current displayed allocation is zero. sUSDai is not sUSDe.'
for a in lr['portfolio']['linked_ui']['allocations']:edge(lr['vault_address'],a['collateral'],'listed_borrower_collateral',lu,active=a['allocation_pct']>0,allocation_pct=a['allocation_pct'],token_address=None)
edge('reUSD','Ethena USDe','historically_reported_backing','https://github.com/yearn/risk-score/blob/master/reports/report/re-reusd.md','historical; current weight unverified',note='Independent Yearn risk analysis of issuer strategy; do not assign a current percentage or confuse reUSDe with USDe.')
edge('ONyc','Ethena sUSDe','historically_reported_backing','https://www.onre.finance/blog/onre-evolves-one-into-onyc-to-power-stablecoin-adoption-across-defi-and-traditional-markets','historical; current weight unverified',publication_date='2025-07-03')
edge('OnRe Kamino market','ONyc','borrower_collateral','https://kamino.com/earn/lend/rockawayx-rwa-usdc/vault-overview','market association verified; collateral mapping unresolved')
edge('siUSD','infinifi','issued_by','https://docs.infinifi.xyz/vaults','verified',note='Current active/paused farm inventory saved in raw/infinifi_vaults.md; weights unavailable. No current Ethena backing assumed.')
for r in risks:
 for a in r['portfolio'].get('market_allocations',[]):
  sym=a['collateral_symbol'] or ''
  if sym.startswith('PT-'):
   edge(sym,'Pendle','principal_token_protocol',links[r['vault_name']], 'PT label verified; Pendle redemption contract mapping not decoded',note='Pendle PT label corroborated by Morpho UI, native token address in market API; exact SY/YT market mapping not collected.')
  if sym.startswith('PT-reUSD'):edge(sym,'reUSD','principal_token_underlying',links[r['vault_name']], 'label verified; redemption contract not decoded')
  if sym=='siUSD':edge(sym,'siUSD','symbol_identity_pending','https://api.morpho.org/graphql',note='Use chain/address in market record for canonical identity.')
with (P/'vaults.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(vaults[0]));w.writeheader();w.writerows(vaults)
dump('dependencies.json',{'collected_at':now,'dashboard_source':'https://dune.com/rockawayxvault/rockawayx-dashboard','coverage':'All 33 dashboard entries; complete adapter market snapshots for 14 Morpho V2 vaults; partial linked UI for Kamino RWA and Lista. Other products have listing-only edges, not complete strategies.','identity_rule':'Deduplicate by chain+address and chain+market_id. Symbols alone are not canonical IDs. Zero/dust allocations retained.','edges':deps})
dump('risk_data.json',{'collected_at':now,'scope':'Mixed-time indexed snapshots, not an atomic on-chain block snapshot. Dune values approximate and cached. No wallet connected or transactions executed.','vaults':risks,'model_requirements':{'liquidation':'For each borrower HF=oracle_valued_collateral*LLTV/debt. Obtain borrower debt/collateral and oracle scaling at one block; market aggregates cannot identify liquidation distribution.','loss':'Market bad debt=max(debt-net_liquidation_recovery,0); allocate to each lender supply share. Do not directly multiply vault USDC TVL by USDe depeg.','issuer_shock':'Backing weight, redemption delays, wrapper/PT pricing, basis and oracle lag required before mapping an Ethena shock to collateral value. Unknown weights remain parameters, not facts.','exit_cost':'Simulate permitted adapter withdrawal, then obtain size-specific DEX/aggregator quotes including gas, bridges, fees and redemption delay. Snapshot liquidity is not a slippage curve.','unique_capital':'Do not sum vault assets, shared market supply, borrower collateral and issuer backing as distinct capital.'}})
print('Built',len(vaults),'inventory records,',len(deps),'edges,',len(risks),'risk records')
