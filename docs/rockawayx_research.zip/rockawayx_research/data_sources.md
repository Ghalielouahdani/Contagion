# RockawayX data access audit

Collection date: 2026-10-10 UTC, approximately 11:45–12:25. Exact per-request timestamps are in raw API records. These are mixed-time indexed snapshots, not an atomic block snapshot.

## Coverage and limitations

All 33 dashboard table entries were captured across both pages. The page contains KPI tiles, chain/protocol/token charts, daily charts, a searchable paginated table, and chart legend controls; no separate strategy-detail tabs were exposed. Product and explorer links are retained in vaults.csv and dashboard_capture.json. Fourteen Morpho V2 products have successful live API and linked UI captures. Kamino RWA, Lista PT, Upshift Tori Ember Y10K and Accountable OnRe Core linked pages were inspected. Other entries have dashboard-level inventory, not complete decoded strategies. Active/inactive status is not established merely by inclusion or positive TVL. Most curator identities outside Morpho remain unverified.

Important failure: main query 6932634 cannot currently execute: `UNION query has different number of fields: 12, 11` (execution ID 01M4JCFJ63XMZ06VEPBF9RGC88). The dashboard still serves cached results. Do not use cached TVL as current capital. Global KPI query reported 293.5624794844196 million USD, 33 entries, eight chains and nine protocols, with `last_updated=2026-10-09 02:13:54`; that is MAX constituent timestamp, not proof every row is fresh. Dashboard chain labels span eight chains. Morpho child query displayed a last run about one month ago and a 2026-08-31 result timestamp. Collection time, cache age, data time, edit time and refresh schedule are different concepts.

Some table addresses identify Kamino lending reserves rather than vaults. In Ember Y10K, the dashboard's eY10K is a receipt token; the linked UI identifies USDC as deposit asset. Earn ctUSD's displayed EVM address is not 42 characters: preserved verbatim, not repaired. Y10K AUSD showed zero dashboard TVL but approximately $5.94m in the live Morpho API. These discrepancies need production ingestion checks.

## Dashboard query catalog

All query URLs are `https://dune.com/queries/{id}`. Public SQL was accessible without signing in where inspected. Saved SQL uses DOM text; long Morpho SQL is explicitly a visible excerpt, not a complete export.

| Query ID | Dashboard use | SQL capture | Immediate source | Cache/run observation |
|---|---|---|---|---|
| 6932634 | Complete vault table | sql/6932634.sql | Nine child queries below | Table cache ~1d; execution currently fails |
| 6960026 | TVL, entries, holders, protocols, chains, average deposit | sql/6960026.sql | dune.rockawayxvault.result_rockaway_vaults_analysis | Last run ~4h; MAX timestamp above |
| 6960146 | TVL by chain | sql/6960146.sql | same materialized result | ~4h badge; schedule unavailable |
| 6960144 | TVL by protocol | sql/6960144.sql | same materialized result | raw/query_6960144.txt |
| 6960147 | TVL by token | sql/6960147.sql | same materialized result | raw/query_6960147.txt |
| 6960156 | Daily TVL by protocol | sql/6960156.sql | dune.rockawayxvault.result_rockaway_vaults_daily_analysis | raw/query_6960156.txt |
| 6960148 | Daily TVL by chain | sql/6960148.sql | same daily materialized result | raw/query_6960148.txt |
| 6960149 | Daily TVL by token | sql/6960149.sql | same daily materialized result | raw/query_6960149.txt |

KPI visual IDs: TVL 10872654; holders 10872708; entries 10872709; chains 10872710; protocols 10872711; average deposit 10911464. Chart visuals: chain 10872888; protocol 10872826; token 10872905; daily protocol 10872944; daily chain 10872974; daily token 10873008; main table 10837851. Raw dashboard links provide exact visual URLs.

### Child queries and blockchain lineage

| ID | Protocol | Inspection status |
|---|---|---|
| 6932588 | Morpho | Public editor/results inspected; visible SQL excerpt saved |
| 6912479 | Midas | Referenced by main SQL; full SQL not collected |
| 6912427 | Kamino | Referenced; full SQL not collected |
| 6973183 | Feather | Referenced; full SQL not collected |
| 7325700 | Ember | Referenced; full SQL not collected |
| 7356289 | Lista | Referenced; full SQL not collected |
| 7444730 | Upshift | Referenced; full SQL not collected |
| 7698787 | Accountable | Referenced; full SQL not collected |
| 8603650 | Oku | Referenced; full SQL not collected |
| 6912265 | Vault registry | Referenced by Morpho SQL; full registry not exported |

Observed Morpho SQL sources: `prices.day`, `morpho_v2_multichain.vaultv2_evt_accrueinterest`, `vaultv2_evt_deposit`, `vaultv2_evt_withdraw`, `vaultv2_evt_transfer`, and query_6912265. Lineage also exposed `metamorpho_vaults_multichain.metamorphov1_1_evt_accrueinterest`, `metamorphov1_1_evt_deposit`, `midas_ethereum.mrox_evt_transfer` and `midas_plume.mmev_evt_transfer`. Full underlying chain tables for every other child were not established. Daily chart queries depend on a materialized result whose complete build SQL was not retrieved.

The Morpho SQL comments explicitly replace a broken EUROP USD price feed with Circle EURC price proxy (EURC address 0x1aBaEA1f7C830bD89Acc67eC4af516284b1bC33c). This proxy is a valuation assumption, not a token equivalence. Ethereum/Base-only pricing in the visible excerpt can miss new chains. Inspect the full current SQL before reproducing that valuation.

### Dune Python access

Documented endpoint: `GET https://api.dune.com/api/v1/query/{query_id}/results/csv`, header `X-DUNE-API-KEY`. JSON equivalent: `/results`. These retrieve existing results; they do not refresh execution. Use execution endpoints and poll status to request fresh results, subject to permissions and credits. [Official CSV documentation](https://docs.dune.com/api-reference/executions/endpoint/get-query-result-csv).

All public query IDs above are candidates for API retrieval; it was **not tested** because no API key was provided. Download/export controls were login-linked, so unauthenticated UI CSV export was not completed. Latest results can be expired, absent, or inconsistent with changed SQL. Query 6932634's fresh execution needs repair by its owner (or a corrected fork), regardless of API availability. No refresh schedule was visible; cache badges are not schedules. Saved public SQL is the available fallback, not a claim all queries were exported.

```python
import os, urllib.request
qid = 6960026
req = urllib.request.Request(
    f'https://api.dune.com/api/v1/query/{qid}/results/csv',
    headers={'X-DUNE-API-KEY': os.environ['DUNE_API_KEY']})
with urllib.request.urlopen(req) as response:
    csv_bytes = response.read()
```

## Tested live Morpho sources

No authentication was needed for these successful requests:

* POST https://api.morpho.org/graphql: `vaultV2ByAddress` for USD assets, APY, liquidity and adapter identities; `userByAddress(adapter)` for market lender positions, collateral tokens, oracle, LLTV, market debt/supply/collateral and liquidity. Exact executable queries and responses are in raw/morpho_live.json; `fetch_live.py` repeats them for the 14 captured addresses.
* GET `https://api.morpho.org/v0/vaults-v2/{chain_id}:{address}`: underlying decimals, owner/curator, gates, fees and configured liquidity adapter/data.
* GET `https://api.morpho.org/v1/vaults-v2/{chain_id}:{address}/state`: raw total, idle, allocated and withdrawable assets, block and share price. Ethereum=1, Base=8453, Monad=143. Exact requests in raw/morpho_rest_*.json.
* Market REST requests tested for 21 Ethereum markets, retained in raw/market_rest.json. Prefer the exact URLs there over constructing an untested endpoint.

The adapter holder is the lender, not necessarily the vault address. Token quantities need decimals; use integers/Decimal in production. Query GraphQL introspection for schema changes. Successful query payloads are preserved; a larger initial inline-fragment request returned HTTP403, archived as a failed probe, and is not the working collector. API timestamps/blocks differ across markets. Reconcile against a single block for simulations.

[Morpho API documentation](https://docs.morpho.org/developers/api/morpho-vaults/). On-chain fallback: read V2 asset, totalAssets, adapter list/configuration, liquidityAdapter/liquidityData, gates and allocation caps; decode each adapter. For Morpho Blue read `idToMarketParams`, `market(id)` and `position(id,user)`, loan/collateral token decimals and oracle `price()` at the same block. Supply/borrow shares require accrued interest conversion. Read oracle component contracts rather than assume a ChainlinkOracleV2 uses one feed. Borrower distributions require indexed events or paginated borrower positions; not collected here.

[V2 withdrawal documentation](https://docs.morpho.org/developers/contracts/morpho-vaults-v2/): maxWithdraw/maxRedeem returning zero is expected. Read/simulate actual permitted routes and force-deallocation penalties; do not apply a V1 withdrawQueue model blindly. Confidential RWA has a non-null send-assets gate in config: its access restrictions require inspection.

## Other official access routes

* **Kamino:** [official kvault repository](https://github.com/Kamino-Finance/kvault) and [klend-sdk examples](https://github.com/Kamino-Finance/klend-sdk/tree/master/examples/kvault-tutorial). Solana `getAccountInfo`/`getMultipleAccounts` plus SDK decoding of VaultState, allocation reserves, Klend reserves and borrower obligations reconstruct the graph. Decode reserve collateral mints and oracle configs; do not treat USDC reserve's 0% collateral LTV as ONyc borrower threshold. Build withdrawal instructions and simulate without signing. Public HTTP API completeness was not established; SDK/RPC is the verified documented fallback, not a fabricated endpoint.
* **Pendle:** [official API docs](https://api-v2.pendle.finance/core/docs), [Hosted SDK](https://docs.pendle.finance/pendle-v2-dev/Backend/HostedSdk). Official base is https://api-v2.pendle.finance/core; `/v2/markets/all` supports discovery. Resolve captured collateral token addresses to chain-specific markets/SY/YT; request size-specific PT-to-token routes and simulate. Endpoint reachability and actual quotes were not tested. Matured Lista PT labels require wrapper/redemption inspection; a Solana PT-rkuSOL label alone does not establish Pendle.
* **Upshift:** linked Tori UI publishes hourly exposure updates and three subaccounts. The captured 2026-10-10 12:05:07 update has Curve, Fluid, Morpho, Pendle V2 and Tori positions. Resolve those wallets and decode positions using RPC/protocol APIs; DeBank links are discovery evidence, not a guaranteed free API. No official public allocation API was established. Receipt redemption is queued for seven days; queue and liquidity UI retained.
* **Ember:** linked Y10K UI identifies three subaccounts, USDC deposit asset, eY10K receipt, twice-weekly price updates and up-to-90-day withdrawal duration. Private deals prevent complete on-chain valuation. No official public strategy API was established.
* **infinifi:** official daily active/paused farm inventory and API documentation retained in raw/infinifi_*.md. An inventory is not backing weights. Aave integrations appearing in paused farm lists do not prove current active exposure by these vaults.
* **Re:** [official links](https://docs.re.xyz/getting-started-with-re/official-links) advertise api.re.xyz/apy and api.re.xyz/price plus attestations. Those endpoints were not queried; historical issuer/Yearn evidence does not determine today's USDe weight. reUSDe is an issuer token, distinct from Ethena USDe.
* **OnRe:** [collateral disclosure](https://docs.onre.finance/for-capital-providers/collateral-composition), [token configuration](https://docs.onre.finance/technical-resources/token-configuration-and-reference), [2025 issuer announcement](https://www.onre.finance/blog/onre-evolves-one-into-onyc-to-power-stablecoin-adoption-across-defi-and-traditional-markets). Current collateral disclosure was blocked in browser; historical sUSDe link is not a current backing percentage. Off-chain reinsurance recovery and issuer redemption terms need attestations.
* **Lista, Midas, Feather, Oku, Accountable:** product/explorer URLs captured. Public complete APIs, redemption contracts and oracle mappings were not verified in this collection. Do not present them as automated integrations already implemented. Discover verified ABI/account schema first.

## Evidence files and reproduction

`vaults.csv` separates cached dashboard approximations from live values. `dependencies.json` identifies relationship type, evidence URL and confidence; indirect backing links explicitly historical. `risk_data.json` retains raw market amounts and provenance. `raw/` includes exact responses and UI text, `sql/` public accessible SQL, `screenshots/` visual context. Run `python fetch_live.py` from this folder to refresh GraphQL; it uses standard-library urllib and the captured configs. This does not refresh Dune or issuer backing. Initial failed probes are labelled by their error payloads. No DEX price-impact curves or borrower-level stress simulation is claimed.

Accountable OnRe Core linked UI was inspected: NAV $3,498,736, publication 8 Oct 11:27 UTC, share price1.041204USDC and standard processing7D. Underlying position-level verification dashboard and oracle feed addresses were not retrieved; NAV is not independently reconciled TVL. raw/accountable_onre.txt preserves the page.
