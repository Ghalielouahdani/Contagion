WITH morpho_vaults AS (
    SELECT
        vault_name,
        vault_name_link,
        vault_address AS vault_address_hex,
        vault_address_link,
        from_hex(SUBSTR(vault_address, 3)) AS vault_address_bin,
        token_name,
        token_address AS token_address_hex,
        token_address_link,
        from_hex(SUBSTR(token_address, 3)) AS token_address_bin,
        -- Mapping prix : le feed EUROP sur Dune est cassé (arrete le 2026-03-20, valeur ~0.33$
        -- au lieu de ~1.16$). On price EUROP via le feed EURC (Circle) sur Ethereum.
        CASE WHEN token_name = 'EUROP'
             THEN from_hex('1aBaEA1f7C830bD89Acc67eC4af516284b1bC33c')
             ELSE from_hex(SUBSTR(token_address, 3))
        END AS price_token_address_bin,
        CASE WHEN token_name = 'EUROP' THEN 'EURC' ELSE token_name END AS price_symbol,
        chain,
        protocol,
        category
    FROM query_6912265
    WHERE protocol = 'morpho'
),
token_decimals AS (
    SELECT
        contract_address,
        blockchain,
        decimals,
        ROW_NUMBER() OVER (
            PARTITION BY blockchain, contract_address
            ORDER BY timestamp DESC, volume DESC
        ) AS rn
    FROM prices.day
    WHERE blockchain IN ('ethereum', 'base')
      AND timestamp >= date_trunc('day', NOW()) - INTERVAL '7' DAY