SELECT
    chain,
    SUM(tvl_usd) AS tvl_usd
FROM dune.rockawayxvault.result_rockaway_vaults_analysis
GROUP BY chain
ORDER BY tvl_usd DESC