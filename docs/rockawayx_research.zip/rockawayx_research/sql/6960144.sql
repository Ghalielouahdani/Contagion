SELECT
    protocol,
    SUM(tvl_usd) AS tvl_usd
FROM dune.rockawayxvault.result_rockaway_vaults_analysis
GROUP BY protocol
ORDER BY tvl_usd DESC