SELECT * FROM query_6932588  -- Morpho latest
UNION ALL
SELECT * FROM query_6912479  -- Midas latest
UNION ALL
SELECT * FROM query_6912427  -- Kamino latest
UNION ALL
SELECT * FROM query_6973183  -- Feather latest
UNION ALL
SELECT * FROM query_7325700  -- Ember latest
UNION ALL
SELECT * FROM query_7356289  -- Lista latest
UNION ALL
SELECT * FROM query_7444730  -- Upshift latest
UNION ALL
SELECT * FROM query_7698787  -- Accountable latest
UNION ALL 
SELECT * FROM query_8603650 --  Oku
ORDER BY tvl_usd DESC