SELECT
    SUM(tvl_usd) / 1e6            AS total_tvl_usd,
    SUM(holders)                  AS total_holders,
    SUM(tvl_usd) / NULLIF(SUM(holders), 0) AS avg_deposit_per_holder_usd,
    COUNT(DISTINCT vault_address) AS nb_vaults,
    COUNT(DISTINCT chain)         AS nb_chains,
    COUNT(DISTINCT protocol)      AS nb_protocols,
    COUNT(DISTINCT token_name)    AS nb_tokens,
    MAX(timestamp)                AS last_updated
FROM dune.rockawayxvault.result_rockaway_vaults_analysis