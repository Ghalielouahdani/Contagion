SELECT
    DATE(date_parse(CAST(timestamp AS varchar), '%Y-%m-%d %H:%i')) AS day,
    chain,
    SUM(tvl_usd) AS tvl_usd
FROM dune.rockawayxvault.result_rockaway_vaults_daily_analysis
GROUP BY DATE(date_parse(CAST(timestamp AS varchar), '%Y-%m-%d %H:%i')), chain
ORDER BY day, chain