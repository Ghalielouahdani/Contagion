SELECT
    token_name,
    SUM(tvl_usd) AS tvl_usd
FROM dune.rockawayxvault.result_rockaway_vaults_analysis
GROUP BY token_name
ORDER BY tvl_usd DESC