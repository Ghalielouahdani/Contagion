SELECT
    DATE(date_parse(CAST(timestamp AS varchar), '%Y-%m-%d %H:%i')) AS day,
    token_name,
    SUM(tvl_usd) AS tvl_usd
FROM dune.rockawayxvault.result_rockaway_vaults_daily_analysis
GROUP BY DATE(date_parse(CAST(timestamp AS varchar), '%Y-%m-%d %H:%i')), token_name
ORDER BY day, token_name