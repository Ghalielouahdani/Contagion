import urllib.request,json,pathlib,concurrent.futures,datetime
P=pathlib.Path(__file__).resolve().parent
ENDPOINT='https://api.morpho.org/graphql'
def gql(q):
 return json.load(urllib.request.urlopen(urllib.request.Request(ENDPOINT,data=json.dumps({'query':q}).encode(),headers={'Content-Type':'application/json'}),timeout=30))
def get(v):
 c=v['response']['data'];d={'address':v['address'],'chain_id':c['chain_id'],'collected_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  q='{vaultV2ByAddress(address:"%s",chainId:%d){totalAssetsUsd liquidityUsd netApy adapters(first:100){items{address type assetsUsd}}}}'%(v['address'],c['chain_id']);d['query']=q;d['response']=gql(q)
  adapters=d['response']['data']['vaultV2ByAddress']['adapters']['items'];d['adapter_positions']=[]
  for a in adapters:
   if a['type']=='MorphoMarketV1':
    q='{userByAddress(address:"%s",chainId:%d){marketPositions{market{marketId lltv irmAddress loanAsset{address symbol decimals} collateralAsset{address symbol decimals price{usd timestamp}} oracle{address type} state{blockNumber timestamp borrowAssets borrowAssetsUsd supplyAssets supplyAssetsUsd collateralAssets collateralAssetsUsd utilization liquidityAssets liquidityAssetsUsd price}} state{timestamp supplyAssets supplyAssetsUsd collateral borrowAssets}}}}'%(a['address'],c['chain_id'])
    d['adapter_positions'].append({'adapter':a['address'],'query':q,'response':gql(q)})
 except Exception as e:d['error']=str(e)
 return d
configs=json.loads((P/'raw/morpho_rest_configs.json').read_text())
out=list(concurrent.futures.ThreadPoolExecutor(max_workers=5).map(get,[v for v in configs if 'response' in v]));(P/'raw/morpho_live.json').write_text(json.dumps(out,indent=2));print([(v['address'],v.get('error'),len(v.get('adapter_positions',[]))) for v in out])
